void count_routing_transistors(enum e_directionality directionality,
			       int num_switch,
			       t_segment_inf * segment_inf,
			       float R_minW_nmos,
			       float R_minW_pmos);
