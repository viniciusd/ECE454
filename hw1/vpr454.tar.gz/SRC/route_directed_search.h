boolean try_directed_search_route(struct s_router_opts router_opts,
				  t_ivec ** fb_opins_used_locally,
				  int width_fac,
				  t_mst_edge ** mst);
