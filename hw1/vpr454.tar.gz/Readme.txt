################################################
# Readme: VPR Quick Start                      #
################################################

Instructions to pack, place, and route a simple circuit:
1.  In the VPR_HET directory, run make
2.  In the T-VPACK_HET directory, run make
3.  In the vpr directory, run go.sh

Read go.sh for a more detailed explanation.
