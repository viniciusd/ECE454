void alloc_and_load_rr_indexed_data(t_segment_inf * segment_inf,
				    int num_segment,
				    t_ivec *** rr_node_indices,
				    int nodes_per_chan,
				    int wire_to_ipin_switch,
				    enum e_base_cost_type base_cost_type);
